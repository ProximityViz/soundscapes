angular.module('app.controllers')
.controller('TutorialCtrl', ['$ionicModal', function($ionicModal) {
	console.log('TutorialCtrl');
}]);
